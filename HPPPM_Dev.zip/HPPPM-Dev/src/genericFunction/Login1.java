package genericFunction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login1 {
public WebDriver validatingFirst() {
		
		//System.setProperty("webdriver.gecko.driver", "D:\\pc00501596\\ATT\\HPPPM\\project_related_jarfiles\\New folder\\geckodriver.exe");
		System.setProperty("webdriver.ie.driver", "D:\\pc00501596\\ATT\\HPPPM\\jars\\Jars\\IEDriverServer.exe");
		
	

		// @SuppressWarnings("deprecation")
		WebDriver driver = new InternetExplorerDriver();
		 driver.manage().window().maximize();  
		
		driver.get("http://zld02292.vci.att.com:8090/itg/dashboard/app/portal/PageView.jsp");
		driver.findElement(By.xpath("//input[@name='userid']")).sendKeys("pc2053");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("8956Att@");
		driver.findElement(By.xpath("//input[@name='btnSubmit']")).click();
		
		WebDriverWait wait = new WebDriverWait(driver,20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='successOK']")));
		
		driver.findElement(By.xpath("//input[@name='successOK']")).click();
		
		return driver;
	}

}
