package genericFunction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class InitialReview {
	
WebDriver driver;
	
	public WebDriver validatingFirstTestCaseIR(WebDriver driver)
	{
		
		driver.findElement(By.xpath("//*[@id='DB1_0']/div")).click();
		
		
		
		
		
		
		return driver;
	
	
	

}
}