package genericFunction;

public interface WebDriver {

}
