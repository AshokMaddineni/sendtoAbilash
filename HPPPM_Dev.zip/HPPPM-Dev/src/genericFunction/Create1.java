package genericFunction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Create1 {
	
	public class Create {

		WebDriver driver;
		
		public WebDriver validatingFirstTestCase(WebDriver driver){
			
			WebDriverWait wait = new WebDriverWait(driver,20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Create")));
			driver.findElement(By.linkText("Create")).click();
			
			
			return this.driver;
		}

}
	
public WebDriver validatingSecondTestCase(WebDriver driver){
		
		driver.findElement(By.linkText("Request")).click();
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("AAMIS")));
		driver.findElement(By.linkText("AAMIS")).click();
		
		//WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='REQ.P.SIFD_CLIENT_ATTUIDAC_TF']")));   //for request link
		
		driver.findElement(By.xpath("//input[@id='REQ.P.SIFD_CLIENT_ATTUIDAC_TF']")).click();
		
		return driver;
	}
	
	public WebDriver validatingThirdTestCase(WebDriver driver)
	{

		//Application
		driver.findElement(By.xpath("//input[@id='REQ.P.AAMIS_APPLICATIONAC_TF']")).sendKeys("HP-PPM");
		WebDriverWait wait = new WebDriverWait(driver,20);
		//SubApplication
		driver.findElement(By.xpath("//*[@id='REQ.P.AAMIS_SUB_APPLICATIONAC_TF']")).sendKeys("ITO-HPPPM");

		//Request Type
		Select select = new Select(driver.findElement(By.xpath("//select[@id='REQ.P.AAMIS_REQUEST_TYPE']")));
		select.selectByVisibleText("Bug");
		
		//Priority
		Select select4 = new Select(driver.findElement(By.xpath("//select[@id='REQ.P.AAMIS_PRIORITY']")));
		select4.selectByVisibleText("2 - Medium");
		
		//Short Description
		driver.findElement(By.xpath("//*[@name='CH_42']")).sendKeys("Test");
		
		//Detailed Description
		driver.findElement(By.xpath("//*[@name='P_41']")).sendKeys("Test");	
		
		//*TSA Compliance
		Select select1 = new Select(driver.findElement(By.xpath("//select[@id='REQD.P.AAMIS_TSA_COMPLIANCE']")));
		select1.selectByVisibleText("Selected");
		
		//NonStop Related
		Select select2 = new Select(driver.findElement(By.xpath("//select[@id='REQD.P.AAMIS_NON_STOP_RELATED']")));
		select2.selectByVisibleText("No");
		
		//SQM Related
		Select select3 = new Select(driver.findElement(By.xpath("//select[@id='REQD.P.AAMIS_SQM_RELATED']")));
		select3.selectByVisibleText("No");
		
		//PPM Request Type
		driver.findElement(By.xpath("//input[@id='REQD.P.AAMIS_PPM_REQUEST_TYPEAC_TF']")).sendKeys("AAMIS");
		

		
		//Submit
		driver.findElement(By.xpath("//a[@id='submit']")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='page-min-width-div']/div[5]/div/div/div[1]/div/table[1]/tbody/tr[3]/td[2]/table/tbody/tr[3]/td[1]/span[2]/a")));
		driver.findElement(By.xpath("//*[@id='page-min-width-div']/div[5]/div/div/div[1]/div/table[1]/tbody/tr[3]/td[2]/table/tbody/tr[3]/td[1]/span[2]/a")).click();
		
		return driver;
	}
	
}