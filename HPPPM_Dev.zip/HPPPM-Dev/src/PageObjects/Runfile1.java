import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import genericFunction.Create1;
import genericFunction.Login1;

public class Runfile1 {

	WebDriver driver;
	
	@BeforeTest
	public void Start()
	{
		Login1 f = new Login1();
		this.driver = f.validatingFirst();
	}
	
	@Test(priority=0)
	public void CreateRequest()
	{
		Create1 create = new Create1();
		create.validatingFirstTestCase(driver);
		create.validatingSecondTestCase(driver);
		create.validatingThirdTestCase(driver);		
	}